package com.rork.lovestoryvideomaker.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddCircle
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.rork.lovestoryvideomaker.ui.screens.CreateScreen
import com.rork.lovestoryvideomaker.ui.screens.HistoryScreen
import com.rork.lovestoryvideomaker.ui.screens.HomeScreen
import com.rork.lovestoryvideomaker.ui.screens.SettingsScreen

private enum class AppDestination(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    Home("home", "Home", Icons.Rounded.Favorite),
    Create("create", "Create", Icons.Rounded.AddCircle),
    History("history", "History", Icons.Rounded.VideoLibrary),
    Settings("settings", "Settings", Icons.Rounded.Settings)
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                AppDestination.entries.forEach { destination ->
                    NavigationBarItem(
                        selected = currentRoute == destination.route,
                        onClick = { navigateTo(destination.route) },
                        icon = { Icon(destination.icon, contentDescription = destination.label) },
                        label = { Text(destination.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = AppDestination.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(AppDestination.Home.route) {
                HomeScreen(
                    onCreateClick = { navigateTo(AppDestination.Create.route) },
                    onHistoryClick = { navigateTo(AppDestination.History.route) }
                )
            }
            composable(AppDestination.Create.route) {
                CreateScreen()
            }
            composable(AppDestination.History.route) {
                HistoryScreen(onCreateClick = { navigateTo(AppDestination.Create.route) })
            }
            composable(AppDestination.Settings.route) {
                SettingsScreen()
            }
        }
    }
}
