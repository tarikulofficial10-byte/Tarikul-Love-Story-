package com.rork.lovestoryvideomaker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rork.lovestoryvideomaker.data.SettingsRepository
import com.rork.lovestoryvideomaker.model.ThemeMode
import com.rork.lovestoryvideomaker.ui.navigation.AppNavigation
import com.rork.lovestoryvideomaker.ui.theme.AppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val settingsRepository = SettingsRepository.getInstance(applicationContext)
        setContent {
            val settings by settingsRepository.settings.collectAsStateWithLifecycle()
            val darkTheme = when (settings.themeMode) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }
            AppTheme(darkTheme = darkTheme) {
                AppNavigation()
            }
        }
    }
}
