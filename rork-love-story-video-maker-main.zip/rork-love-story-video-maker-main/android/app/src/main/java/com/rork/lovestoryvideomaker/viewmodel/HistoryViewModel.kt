package com.rork.lovestoryvideomaker.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rork.lovestoryvideomaker.data.HistoryRepository
import com.rork.lovestoryvideomaker.model.HistoryItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class HistoryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = HistoryRepository.getInstance(application)

    val items: StateFlow<List<HistoryItem>> = repository.items

    fun delete(item: HistoryItem) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.delete(item)
        }
    }
}
