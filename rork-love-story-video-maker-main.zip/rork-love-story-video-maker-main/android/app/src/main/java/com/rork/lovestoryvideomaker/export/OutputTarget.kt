package com.rork.lovestoryvideomaker.export

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import java.io.File
import java.io.IOException

/**
 * Wraps the MP4 destination: a pending MediaStore entry (API 29+) or a
 * public Movies file on older devices. Handles finalize and abort cleanup.
 */
class OutputTarget private constructor(
    val muxer: MediaMuxer,
    private val resolver: ContentResolver,
    private val pfd: ParcelFileDescriptor?,
    private val legacyFile: File?,
    private val fileName: String,
    contentUri: Uri
) {
    var contentUri: Uri = contentUri
        private set

    /** Releases the muxer and publishes the video to the gallery. */
    fun finish(durationMs: Long) {
        runCatching { muxer.release() }
        pfd?.close()
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
                put(MediaStore.Video.Media.DURATION, durationMs)
            }
            resolver.update(contentUri, values, null, null)
        } else if (legacyFile != null) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DATA, legacyFile.absolutePath)
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.DURATION, durationMs)
            }
            val inserted = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            if (inserted != null) contentUri = inserted
        }
    }

    /** Deletes any partial output after a failure or cancellation. */
    fun abort() {
        runCatching { muxer.release() }
        runCatching { pfd?.close() }
        if (Build.VERSION.SDK_INT >= 29) {
            runCatching { resolver.delete(contentUri, null, null) }
        } else {
            runCatching { legacyFile?.delete() }
        }
    }

    fun resultSize(): Long {
        if (legacyFile != null) return legacyFile.length()
        var size = 0L
        runCatching {
            resolver.query(
                contentUri, arrayOf(MediaStore.MediaColumns.SIZE), null, null, null
            )?.use { cursor ->
                if (cursor.moveToFirst() && !cursor.isNull(0)) size = cursor.getLong(0)
            }
        }
        return size
    }

    companion object {
        private const val ALBUM_DIR = "Love Story Maker"

        fun create(context: Context, fileName: String): OutputTarget {
            val resolver = context.contentResolver
            return if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                    put(
                        MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_MOVIES + "/" + ALBUM_DIR
                    )
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val uri = resolver.insert(
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),
                    values
                ) ?: throw IOException("Could not create a gallery entry")
                val pfd = resolver.openFileDescriptor(uri, "rw")
                    ?: throw IOException("Could not open the gallery file for writing")
                val muxer = MediaMuxer(
                    pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
                )
                OutputTarget(muxer, resolver, pfd, null, fileName, uri)
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    ALBUM_DIR
                )
                if (!dir.exists() && !dir.mkdirs()) {
                    throw IOException("Could not create the output folder")
                }
                val file = File(dir, fileName)
                val muxer = MediaMuxer(
                    file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
                )
                OutputTarget(muxer, resolver, null, file, fileName, Uri.fromFile(file))
            }
        }
    }
}
