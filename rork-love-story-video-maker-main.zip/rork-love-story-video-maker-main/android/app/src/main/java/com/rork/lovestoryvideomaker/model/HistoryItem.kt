package com.rork.lovestoryvideomaker.model

import kotlinx.serialization.Serializable

/** A previously exported video saved to the gallery. */
@Serializable
data class HistoryItem(
    val id: String,
    val fileName: String,
    val uri: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val resolutionLabel: String,
    val fps: Int,
    val sizeBytes: Long,
    val dateMillis: Long,
    val thumbnailPath: String?
)
