package com.rork.lovestoryvideomaker.export

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import com.rork.lovestoryvideomaker.MainActivity
import com.rork.lovestoryvideomaker.R
import com.rork.lovestoryvideomaker.data.HistoryRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Foreground service that renders the video so exports survive backgrounding. */
class ExportService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var lastNotificationUpdate = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val request = ExportManager.consumeRequest()
        if (request == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        createChannel()
        startInForeground(buildNotification(0))

        scope.launch {
            try {
                val composer = VideoComposer(applicationContext)
                val item = composer.compose(
                    request,
                    onProgress = { progress, phase, etaMs ->
                        ExportManager.setRunning(progress, phase, etaMs)
                        maybeUpdateNotification(progress)
                    },
                    isCancelled = ExportManager::isCancelRequested
                )
                HistoryRepository.getInstance(applicationContext).add(item)
                ExportManager.setCompleted(item)
            } catch (_: ExportCancelledException) {
                ExportManager.setCancelled()
            } catch (t: Throwable) {
                Log.e(TAG, "Export failed", t)
                ExportManager.setFailed(t.message ?: "Something went wrong during export")
            } finally {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun startInForeground(notification: Notification) {
        when {
            Build.VERSION.SDK_INT >= 35 -> startForeground(
                NOTIFICATION_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING
            )
            Build.VERSION.SDK_INT >= 29 -> startForeground(
                NOTIFICATION_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
            else -> startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun maybeUpdateNotification(progress: Float) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastNotificationUpdate < 700) return
        lastNotificationUpdate = now
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification((progress * 100).toInt()))
    }

    private fun buildNotification(percent: Int): Notification {
        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Creating your love story video")
            .setContentText("$percent% complete")
            .setProgress(100, percent, percent == 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentIntent)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Video export",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Progress of video exports" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        private const val TAG = "ExportService"
        private const val CHANNEL_ID = "export_progress"
        private const val NOTIFICATION_ID = 42
    }
}
