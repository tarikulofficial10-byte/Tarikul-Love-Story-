package com.rork.lovestoryvideomaker.model

/**
 * Export resolutions supported by the app. Width/height describe the
 * landscape variant; portrait output swaps the two dimensions.
 */
enum class Resolution(
    val label: String,
    val longSide: Int,
    val shortSide: Int,
    val bitrate: Int
) {
    P720("720p", 1280, 720, 5_000_000),
    P1080("1080p", 1920, 1080, 9_000_000),
    P1440("1440p", 2560, 1440, 16_000_000),
    P2160("4K", 3840, 2160, 30_000_000);

    companion object {
        fun fromName(name: String?): Resolution =
            entries.firstOrNull { it.name == name } ?: P1080
    }
}
