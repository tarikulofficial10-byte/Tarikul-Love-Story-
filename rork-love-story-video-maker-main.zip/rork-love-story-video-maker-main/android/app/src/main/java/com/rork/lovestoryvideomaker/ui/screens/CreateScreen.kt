package com.rork.lovestoryvideomaker.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MovieFilter
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil3.compose.AsyncImage
import com.rork.lovestoryvideomaker.export.ExportState
import com.rork.lovestoryvideomaker.model.HistoryItem
import com.rork.lovestoryvideomaker.model.Resolution
import com.rork.lovestoryvideomaker.util.Formatters
import com.rork.lovestoryvideomaker.util.VideoActions
import com.rork.lovestoryvideomaker.viewmodel.CreateViewModel
import java.io.File

private val durationPresets = listOf(
    "10 min" to 10 * 60_000L,
    "30 min" to 30 * 60_000L,
    "1 hour" to 3_600_000L,
    "2 hours" to 7_200_000L,
    "3 hours" to 10_800_000L,
    "5 hours" to 18_000_000L
)

@Composable
fun CreateScreen(viewModel: CreateViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val exportState by viewModel.exportState.collectAsStateWithLifecycle()

    when (val state = exportState) {
        is ExportState.Running -> ExportProgressContent(state, viewModel::cancelExport)
        is ExportState.Completed -> ExportCompletedContent(state.item, viewModel::acknowledgeExport)
        is ExportState.Failed -> ExportFailedContent(state.message, viewModel::acknowledgeExport)
        is ExportState.Cancelled -> ExportCancelledContent(viewModel::acknowledgeExport)
        is ExportState.Idle -> CreateFormContent(uiState, viewModel)
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun CreateFormContent(
    uiState: CreateViewModel.CreateUiState,
    viewModel: CreateViewModel
) {
    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> uri?.let(viewModel::setImage) }

    val audioPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let(viewModel::setAudio) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { viewModel.startExport() }

    fun requestPermissionsAndStart() {
        val permissions = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT <= 28) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        if (permissions.isEmpty()) viewModel.startExport()
        else permissionLauncher.launch(permissions.toTypedArray())
    }

    var showCustomDuration by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text("Create Video", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Three little steps to your love story",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))

        StepCard(step = "1", title = "Photo") {
            if (uiState.imageUri == null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(vertical = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Rounded.AddPhotoAlternate,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("JPG · JPEG · PNG · WebP", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        photoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }) { Text("Choose a photo") }
                }
            } else {
                Box {
                    AsyncImage(
                        model = uiState.imageUri,
                        contentDescription = "Selected photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 10f)
                            .clip(RoundedCornerShape(16.dp))
                    )
                    FilledTonalButton(
                        onClick = {
                            photoPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                    ) { Text("Replace") }
                }
            }
        }

        StepCard(step = "2", title = "Audio") {
            val audio = uiState.audio
            if (audio == null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AudioBadge()
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Select a song from your files", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "MP3 · WAV · M4A · AAC · OGG",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(onClick = { audioPicker.launch(arrayOf("audio/*")) }) { Text("Browse") }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AudioBadge()
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            audio.name,
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val meta = buildString {
                            append(Formatters.timestamp(audio.durationMs))
                            append(" · ")
                            append(Formatters.fileSize(audio.sizeBytes))
                            formatLabel(audio.mimeType)?.let { append(" · $it") }
                        }
                        Text(
                            meta,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }) { Text("Change") }
                }
            }
        }

        StepCard(step = "3", title = "Video length") {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                durationPresets.forEach { (label, ms) ->
                    FilterChip(
                        selected = uiState.durationMs == ms,
                        onClick = { viewModel.setDuration(ms) },
                        label = { Text(label) }
                    )
                }
                val isCustom = durationPresets.none { it.second == uiState.durationMs }
                FilterChip(
                    selected = isCustom,
                    onClick = { showCustomDuration = true },
                    label = { Text(if (isCustom) "Custom · ${Formatters.duration(uiState.durationMs)}" else "Custom…") }
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Your photo stays on screen and the song loops for ${Formatters.duration(uiState.durationMs)}.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        StepCard(step = "4", title = "Quality") {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                Resolution.entries.forEachIndexed { index, res ->
                    val enabled = res != Resolution.P2160 || uiState.fourKSupported
                    SegmentedButton(
                        selected = uiState.resolution == res,
                        onClick = { viewModel.setResolution(res) },
                        enabled = enabled,
                        shape = SegmentedButtonDefaults.itemShape(
                            index = index, count = Resolution.entries.size
                        ),
                        icon = {}
                    ) { Text(res.label) }
                }
            }
            Spacer(Modifier.height(8.dp))
            val qualityNote = if (!uiState.fourKSupported) {
                "4K isn't supported on this device · MP4 (H.264) with AAC audio at ${uiState.fps} fps"
            } else {
                "MP4 (H.264) with AAC audio at ${uiState.fps} fps — change frame rate in Settings"
            }
            Text(
                qualityNote,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        SummaryCard(uiState)
        Spacer(Modifier.height(16.dp))

        uiState.validationError?.let { error ->
            Text(
                error,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        Button(
            onClick = { requestPermissionsAndStart() },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Icon(Icons.Rounded.MovieFilter, contentDescription = null)
            Spacer(Modifier.width(10.dp))
            Text("Create Video", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showCustomDuration) {
        CustomDurationDialog(
            initialMs = uiState.durationMs,
            onConfirm = { ms ->
                viewModel.setDuration(ms)
                showCustomDuration = false
            },
            onDismiss = { showCustomDuration = false }
        )
    }
}

@Composable
private fun StepCard(step: String, title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        )
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        step,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
                Spacer(Modifier.width(10.dp))
                Text(title, style = MaterialTheme.typography.titleLarge)
            }
            Spacer(Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
private fun AudioBadge() {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Rounded.MusicNote,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimaryContainer
        )
    }
}

@Composable
private fun SummaryCard(uiState: CreateViewModel.CreateUiState) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f)
        )
    ) {
        Column(Modifier.padding(16.dp)) {
            SummaryRow("Estimated file size", "~" + Formatters.fileSize(
                estimatedSizeBytes(uiState.resolution, uiState.durationMs)
            ))
            SummaryRow("Estimated export time", "~" + Formatters.duration(
                estimatedExportMs(uiState.durationMs)
            ))
            SummaryRow("Saved to", "Gallery · Movies/Love Story Maker")
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun CustomDurationDialog(
    initialMs: Long,
    onConfirm: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var hoursText by remember { mutableStateOf((initialMs / 3_600_000L).toString()) }
    var minutesText by remember { mutableStateOf(((initialMs % 3_600_000L) / 60_000L).toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom duration") },
        text = {
            Column {
                Text(
                    "Choose any length up to 6 hours.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = hoursText,
                        onValueChange = { hoursText = it.filter { c -> c.isDigit() }.take(1) },
                        label = { Text("Hours") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minutesText,
                        onValueChange = { minutesText = it.filter { c -> c.isDigit() }.take(3) },
                        label = { Text("Minutes") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val hours = hoursText.toLongOrNull() ?: 0L
                val minutes = minutesText.toLongOrNull() ?: 0L
                val ms = (hours * 3_600_000L + minutes * 60_000L)
                    .coerceIn(5_000L, 6 * 3_600_000L)
                onConfirm(ms)
            }) { Text("Set duration") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun ExportProgressContent(state: ExportState.Running, onCancel: () -> Unit) {
    val animatedProgress by animateFloatAsState(
        targetValue = state.progress,
        animationSpec = tween(400),
        label = "exportProgress"
    )
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier.size(200.dp),
                strokeWidth = 10.dp,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "${(state.progress * 100).toInt()}%",
                    style = MaterialTheme.typography.displaySmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    state.phase,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(20.dp))
        state.etaMs?.let {
            Text(Formatters.eta(it), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
        }
        Text(
            "You can leave the app — the export keeps running in the background.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        OutlinedButton(onClick = onCancel) {
            Icon(Icons.Rounded.Cancel, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Cancel export")
        }
    }
}

@Composable
private fun ExportCompletedContent(item: HistoryItem, onDone: () -> Unit) {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Rounded.CheckCircle,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(56.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text("Your video is ready!", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Saved to your gallery",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))
        Card {
            Column {
                if (item.thumbnailPath != null) {
                    AsyncImage(
                        model = File(item.thumbnailPath),
                        contentDescription = item.fileName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                    )
                }
                Column(Modifier.padding(16.dp)) {
                    Text(
                        item.fileName,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "${Formatters.duration(item.durationMs)} · ${item.resolutionLabel} · ${item.fps} fps · ${Formatters.fileSize(item.sizeBytes)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { VideoActions.open(context, item) }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Play")
            }
            OutlinedButton(onClick = { VideoActions.share(context, item) }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Share")
            }
        }
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onDone) { Text("Create another video") }
    }
}

@Composable
private fun ExportFailedContent(message: String, onDismiss: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Rounded.ErrorOutline,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(56.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text("Export failed", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onDismiss) { Text("Try again") }
    }
}

@Composable
private fun ExportCancelledContent(onDismiss: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Rounded.Info,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(56.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text("Export cancelled", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Nothing was saved to your gallery.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onDismiss) { Text("Back to setup") }
    }
}

private fun formatLabel(mime: String?): String? = when {
    mime == null -> null
    mime.contains("mpeg") -> "MP3"
    mime.contains("wav") -> "WAV"
    mime.contains("mp4") || mime.contains("m4a") -> "M4A"
    mime.contains("aac") -> "AAC"
    mime.contains("ogg") -> "OGG"
    else -> mime.substringAfter('/').uppercase().take(4)
}

private fun estimatedSizeBytes(resolution: Resolution, durationMs: Long): Long {
    val seconds = durationMs / 1000.0
    val videoBps = resolution.bitrate * 0.10
    val audioBps = 192_000.0
    return ((videoBps + audioBps) / 8.0 * seconds).toLong()
}

private fun estimatedExportMs(durationMs: Long): Long = 30_000L + durationMs / 50L
