package com.rork.lovestoryvideomaker.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import com.rork.lovestoryvideomaker.model.HistoryItem

/** Shared open/share intents for exported videos. */
object VideoActions {

    fun open(context: Context, item: HistoryItem) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse(item.uri), "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "No player available", e)
            Toast.makeText(context, "No video player app found", Toast.LENGTH_SHORT).show()
        }
    }

    fun share(context: Context, item: HistoryItem) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, Uri.parse(item.uri))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share video"))
        } catch (e: Exception) {
            Log.e(TAG, "Share failed", e)
            Toast.makeText(context, "Could not share this video", Toast.LENGTH_SHORT).show()
        }
    }

    private const val TAG = "VideoActions"
}
