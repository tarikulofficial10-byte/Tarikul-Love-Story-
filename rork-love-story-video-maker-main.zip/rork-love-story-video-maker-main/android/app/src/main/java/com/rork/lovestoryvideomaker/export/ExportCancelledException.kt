package com.rork.lovestoryvideomaker.export

/** Thrown internally when the user cancels a running export. */
class ExportCancelledException : Exception("Export cancelled by user")
