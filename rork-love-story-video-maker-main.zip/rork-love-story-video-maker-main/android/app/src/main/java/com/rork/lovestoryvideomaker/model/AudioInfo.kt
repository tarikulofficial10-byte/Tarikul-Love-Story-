package com.rork.lovestoryvideomaker.model

import kotlinx.serialization.Serializable

/** Metadata about the audio track picked by the user. */
@Serializable
data class AudioInfo(
    val uri: String,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val mimeType: String?
)
