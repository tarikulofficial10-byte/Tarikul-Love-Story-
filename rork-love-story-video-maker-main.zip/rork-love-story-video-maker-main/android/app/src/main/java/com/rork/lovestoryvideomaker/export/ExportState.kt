package com.rork.lovestoryvideomaker.export

import com.rork.lovestoryvideomaker.model.HistoryItem

/** Observable state of the current (or last) export job. */
sealed interface ExportState {
    data object Idle : ExportState

    data class Running(
        val progress: Float,
        val phase: String,
        val etaMs: Long?
    ) : ExportState

    data class Completed(val item: HistoryItem) : ExportState

    data class Failed(val message: String) : ExportState

    data object Cancelled : ExportState
}
