package com.rork.lovestoryvideomaker.export

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.rork.lovestoryvideomaker.model.ExportRequest
import com.rork.lovestoryvideomaker.model.HistoryItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Bridge between the UI and the background export service.
 * Holds the observable export state for the whole app.
 */
object ExportManager {

    private val _state = MutableStateFlow<ExportState>(ExportState.Idle)
    val state: StateFlow<ExportState> = _state.asStateFlow()

    @Volatile
    private var pendingRequest: ExportRequest? = null

    @Volatile
    private var cancelRequested = false

    val isRunning: Boolean get() = _state.value is ExportState.Running

    /** Starts the foreground export service. Returns false if already busy. */
    fun start(context: Context, request: ExportRequest): Boolean {
        if (isRunning) return false
        pendingRequest = request
        cancelRequested = false
        _state.value = ExportState.Running(0f, "Starting export…", null)
        val intent = Intent(context, ExportService::class.java)
        ContextCompat.startForegroundService(context, intent)
        return true
    }

    fun requestCancel() {
        cancelRequested = true
    }

    fun isCancelRequested(): Boolean = cancelRequested

    internal fun consumeRequest(): ExportRequest? {
        val request = pendingRequest
        pendingRequest = null
        return request
    }

    internal fun setRunning(progress: Float, phase: String, etaMs: Long?) {
        _state.value = ExportState.Running(progress, phase, etaMs)
    }

    internal fun setCompleted(item: HistoryItem) {
        _state.value = ExportState.Completed(item)
    }

    internal fun setFailed(message: String) {
        _state.value = ExportState.Failed(message)
    }

    internal fun setCancelled() {
        _state.value = ExportState.Cancelled
    }

    /** Clears a finished/failed/cancelled state back to idle. */
    fun acknowledge() {
        if (_state.value !is ExportState.Running) {
            _state.value = ExportState.Idle
        }
    }
}
