package com.rork.lovestoryvideomaker.model

data class AppSettings(
    val defaultResolution: Resolution = Resolution.P1080,
    val frameRate: Int = 30,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val language: String = "English"
)
