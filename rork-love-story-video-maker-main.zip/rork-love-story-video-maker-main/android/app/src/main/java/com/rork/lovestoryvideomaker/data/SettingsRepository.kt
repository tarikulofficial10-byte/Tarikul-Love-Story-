package com.rork.lovestoryvideomaker.data

import android.content.Context
import android.content.SharedPreferences
import com.rork.lovestoryvideomaker.model.AppSettings
import com.rork.lovestoryvideomaker.model.Resolution
import com.rork.lovestoryvideomaker.model.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Persists user preferences and exposes them as a StateFlow. */
class SettingsRepository private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun load(): AppSettings = AppSettings(
        defaultResolution = Resolution.fromName(prefs.getString(KEY_RESOLUTION, null)),
        frameRate = prefs.getInt(KEY_FPS, 30),
        themeMode = ThemeMode.fromName(prefs.getString(KEY_THEME, null)),
        language = prefs.getString(KEY_LANGUAGE, "English") ?: "English"
    )

    fun setDefaultResolution(resolution: Resolution) {
        prefs.edit().putString(KEY_RESOLUTION, resolution.name).apply()
        _settings.value = _settings.value.copy(defaultResolution = resolution)
    }

    fun setFrameRate(fps: Int) {
        prefs.edit().putInt(KEY_FPS, fps).apply()
        _settings.value = _settings.value.copy(frameRate = fps)
    }

    fun setThemeMode(mode: ThemeMode) {
        prefs.edit().putString(KEY_THEME, mode.name).apply()
        _settings.value = _settings.value.copy(themeMode = mode)
    }

    companion object {
        private const val KEY_RESOLUTION = "default_resolution"
        private const val KEY_FPS = "frame_rate"
        private const val KEY_THEME = "theme_mode"
        private const val KEY_LANGUAGE = "language"

        @Volatile
        private var instance: SettingsRepository? = null

        fun getInstance(context: Context): SettingsRepository =
            instance ?: synchronized(this) {
                instance ?: SettingsRepository(context.applicationContext).also { instance = it }
            }
    }
}
