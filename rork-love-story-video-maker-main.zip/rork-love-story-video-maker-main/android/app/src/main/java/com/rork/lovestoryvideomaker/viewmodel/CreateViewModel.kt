package com.rork.lovestoryvideomaker.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rork.lovestoryvideomaker.data.SettingsRepository
import com.rork.lovestoryvideomaker.export.ExportManager
import com.rork.lovestoryvideomaker.export.ExportState
import com.rork.lovestoryvideomaker.export.StillImageEncoder
import com.rork.lovestoryvideomaker.model.AudioInfo
import com.rork.lovestoryvideomaker.model.ExportRequest
import com.rork.lovestoryvideomaker.model.Resolution
import com.rork.lovestoryvideomaker.util.MediaInfoResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class CreateViewModel(application: Application) : AndroidViewModel(application) {

    data class CreateUiState(
        val imageUri: String? = null,
        val audio: AudioInfo? = null,
        val durationMs: Long = 10 * 60_000L,
        val resolution: Resolution = Resolution.P1080,
        val fps: Int = 30,
        val fourKSupported: Boolean = true,
        val validationError: String? = null
    )

    private val _uiState = MutableStateFlow(CreateUiState())
    val uiState: StateFlow<CreateUiState> = _uiState.asStateFlow()

    val exportState: StateFlow<ExportState> = ExportManager.state

    init {
        val repo = SettingsRepository.getInstance(application)
        _uiState.update {
            it.copy(
                resolution = repo.settings.value.defaultResolution,
                fps = repo.settings.value.frameRate
            )
        }
        viewModelScope.launch {
            repo.settings.collect { s -> _uiState.update { it.copy(fps = s.frameRate) } }
        }
        viewModelScope.launch(Dispatchers.Default) {
            val supported = StillImageEncoder.isResolutionSupported(
                Resolution.P2160.longSide, Resolution.P2160.shortSide
            )
            _uiState.update {
                it.copy(
                    fourKSupported = supported,
                    resolution = if (!supported && it.resolution == Resolution.P2160) {
                        Resolution.P1080
                    } else it.resolution
                )
            }
        }
    }

    fun setImage(uri: Uri) {
        _uiState.update { it.copy(imageUri = uri.toString(), validationError = null) }
    }

    fun setAudio(uri: Uri) {
        try {
            getApplication<Application>().contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // Non-persistable grant; the in-process grant is enough for export.
        }
        viewModelScope.launch(Dispatchers.IO) {
            val info = MediaInfoResolver.resolveAudio(getApplication(), uri)
            _uiState.update { it.copy(audio = info, validationError = null) }
        }
    }

    fun setDuration(ms: Long) {
        _uiState.update { it.copy(durationMs = ms, validationError = null) }
    }

    fun setResolution(resolution: Resolution) {
        _uiState.update { it.copy(resolution = resolution, validationError = null) }
    }

    /** Validates the form and hands the job to the background exporter. */
    fun startExport() {
        val s = _uiState.value
        val error = when {
            s.imageUri == null -> "Please choose a photo first"
            s.audio == null -> "Please select an audio track"
            s.durationMs < 5_000L -> "Duration must be at least 5 seconds"
            s.durationMs > 6 * 3_600_000L -> "Maximum duration is 6 hours"
            else -> null
        }
        if (error != null) {
            _uiState.update { it.copy(validationError = error) }
            return
        }
        ExportManager.start(
            getApplication(),
            ExportRequest(
                imageUri = s.imageUri!!,
                audio = s.audio!!,
                durationMs = s.durationMs,
                resolution = s.resolution,
                fps = s.fps
            )
        )
    }

    fun cancelExport() = ExportManager.requestCancel()

    fun acknowledgeExport() = ExportManager.acknowledge()
}
