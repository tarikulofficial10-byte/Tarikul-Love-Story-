package com.rork.lovestoryvideomaker.export

import android.graphics.Bitmap
import android.media.Image

/** Converts an ARGB bitmap into I420 planes and fills MediaCodec input images. */
object YuvConverter {

    class I420(val width: Int, val height: Int) {
        val y = ByteArray(width * height)
        val u = ByteArray((width / 2) * (height / 2))
        val v = ByteArray((width / 2) * (height / 2))
    }

    /** BT.601 limited-range RGB to YUV420 conversion. */
    fun fromBitmap(bitmap: Bitmap): I420 {
        val w = bitmap.width
        val h = bitmap.height
        val out = I420(w, h)
        val row = IntArray(w)
        val halfW = w / 2
        for (j in 0 until h) {
            bitmap.getPixels(row, 0, w, 0, j, w, 1)
            val yRow = j * w
            for (i in 0 until w) {
                val c = row[i]
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                val yy = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                out.y[yRow + i] = yy.coerceIn(0, 255).toByte()
                if (j % 2 == 0 && i % 2 == 0) {
                    val uu = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                    val vv = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                    val chromaIdx = (j / 2) * halfW + (i / 2)
                    out.u[chromaIdx] = uu.coerceIn(0, 255).toByte()
                    out.v[chromaIdx] = vv.coerceIn(0, 255).toByte()
                }
            }
        }
        return out
    }

    /** Copies I420 planes into a flexible-format encoder input [Image]. */
    fun fill(image: Image, src: I420) {
        val planes = image.planes
        copyPlane(planes[0], src.y, src.width, src.height)
        copyPlane(planes[1], src.u, src.width / 2, src.height / 2)
        copyPlane(planes[2], src.v, src.width / 2, src.height / 2)
    }

    private fun copyPlane(plane: Image.Plane, data: ByteArray, w: Int, h: Int) {
        val buf = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        if (pixelStride == 1) {
            var srcPos = 0
            for (rowIdx in 0 until h) {
                buf.position(rowIdx * rowStride)
                buf.put(data, srcPos, w)
                srcPos += w
            }
        } else {
            val limit = buf.limit()
            for (rowIdx in 0 until h) {
                var p = rowIdx * rowStride
                val srcRow = rowIdx * w
                for (col in 0 until w) {
                    if (p < limit) buf.put(p, data[srcRow + col])
                    p += pixelStride
                }
            }
        }
    }
}
