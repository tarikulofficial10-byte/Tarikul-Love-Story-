package com.rork.lovestoryvideomaker.export

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteBuffer

/**
 * Decodes any supported audio source (MP3, WAV, M4A, AAC, OGG) to PCM and
 * re-encodes it as AAC-LC samples, trimmed to at most [maxDurationUs].
 */
class AudioTranscoder {

    var outputFormat: MediaFormat? = null
        private set

    private var sampleRate = 44_100
    private var channels = 2

    fun transcode(
        context: Context,
        uri: Uri,
        maxDurationUs: Long,
        store: SampleStore,
        onProgress: (Float) -> Unit,
        isCancelled: () -> Boolean
    ) {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var encoder: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            val trackIndex = (0 until extractor.trackCount).firstOrNull { idx ->
                extractor.getTrackFormat(idx).getString(MediaFormat.KEY_MIME)
                    ?.startsWith("audio/") == true
            } ?: throw IllegalStateException("No audio track found in the selected file")

            extractor.selectTrack(trackIndex)
            val srcFormat = extractor.getTrackFormat(trackIndex)
            val srcMime = srcFormat.getString(MediaFormat.KEY_MIME)
                ?: throw IllegalStateException("Unknown audio format")
            val srcDurationUs = if (srcFormat.containsKey(MediaFormat.KEY_DURATION)) {
                srcFormat.getLong(MediaFormat.KEY_DURATION)
            } else maxDurationUs
            val targetUs = minOf(srcDurationUs, maxDurationUs).coerceAtLeast(1L)

            srcFormat.setInteger(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
            val dec = MediaCodec.createDecoderByType(srcMime)
            decoder = dec
            dec.configure(srcFormat, null, null, 0)
            dec.start()

            var enc: MediaCodec? = null
            var extractorDone = false
            var decoderDone = false
            var encoderEosSent = false
            var encoderDone = false
            var totalPcmBytes = 0L
            var lastEncPtsUs = 0L
            var stall = 0

            // The decoder output chunk currently being drip-fed into the encoder.
            var pendingIndex = -1
            var pendingBuffer: ByteBuffer? = null

            val decInfo = MediaCodec.BufferInfo()
            val encInfo = MediaCodec.BufferInfo()

            fun ensureEncoder() {
                if (enc != null) return
                val fmt = dec.outputFormat
                sampleRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                val encFormat = MediaFormat.createAudioFormat(
                    MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels
                ).apply {
                    setInteger(
                        MediaFormat.KEY_AAC_PROFILE,
                        MediaCodecInfo.CodecProfileLevel.AACObjectLC
                    )
                    setInteger(MediaFormat.KEY_BIT_RATE, if (channels >= 2) 192_000 else 128_000)
                    setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
                }
                val created = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
                created.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                created.start()
                enc = created
                encoder = created
            }

            while (!encoderDone) {
                if (isCancelled()) throw ExportCancelledException()
                var progressed = false

                // 1. Feed compressed source data into the decoder.
                if (!extractorDone) {
                    val idx = dec.dequeueInputBuffer(5_000)
                    if (idx >= 0) {
                        progressed = true
                        val buf = dec.getInputBuffer(idx)!!
                        val read = extractor.readSampleData(buf, 0)
                        val sampleTime = extractor.sampleTime
                        if (read < 0 || sampleTime > maxDurationUs) {
                            dec.queueInputBuffer(
                                idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            extractorDone = true
                        } else {
                            dec.queueInputBuffer(idx, 0, read, sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                // 2. Pull decoded PCM if the previous chunk was fully consumed.
                if (!decoderDone && pendingBuffer == null) {
                    val idx = dec.dequeueOutputBuffer(decInfo, 5_000)
                    when {
                        idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            ensureEncoder()
                            progressed = true
                        }
                        idx >= 0 -> {
                            progressed = true
                            ensureEncoder()
                            if (decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                                decoderDone = true
                            }
                            if (decInfo.size > 0) {
                                val buf = dec.getOutputBuffer(idx)!!
                                buf.position(decInfo.offset)
                                buf.limit(decInfo.offset + decInfo.size)
                                pendingIndex = idx
                                pendingBuffer = buf
                            } else {
                                dec.releaseOutputBuffer(idx, false)
                            }
                        }
                    }
                }

                // 3. Feed PCM into the AAC encoder.
                val activeEnc = enc
                if (activeEnc != null && !encoderEosSent &&
                    (pendingBuffer != null || decoderDone)
                ) {
                    val idx = activeEnc.dequeueInputBuffer(5_000)
                    if (idx >= 0) {
                        progressed = true
                        val chunk = pendingBuffer
                        if (chunk != null) {
                            val inBuf = activeEnc.getInputBuffer(idx)!!
                            inBuf.clear()
                            val toCopy = minOf(inBuf.remaining(), chunk.remaining())
                            val oldLimit = chunk.limit()
                            chunk.limit(chunk.position() + toCopy)
                            inBuf.put(chunk)
                            chunk.limit(oldLimit)
                            val ptsUs = totalPcmBytes * 1_000_000L /
                                (sampleRate.toLong() * channels * 2L)
                            totalPcmBytes += toCopy
                            activeEnc.queueInputBuffer(idx, 0, toCopy, ptsUs, 0)
                            if (!chunk.hasRemaining()) {
                                dec.releaseOutputBuffer(pendingIndex, false)
                                pendingIndex = -1
                                pendingBuffer = null
                            }
                        } else {
                            activeEnc.queueInputBuffer(
                                idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            encoderEosSent = true
                        }
                    }
                }

                // 4. Drain encoded AAC samples into the store.
                if (activeEnc != null) {
                    val idx = activeEnc.dequeueOutputBuffer(encInfo, 5_000)
                    when {
                        idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            outputFormat = activeEnc.outputFormat
                            progressed = true
                        }
                        idx >= 0 -> {
                            progressed = true
                            val isConfig =
                                encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                            if (!isConfig && encInfo.size > 0) {
                                store.append(activeEnc.getOutputBuffer(idx)!!, encInfo)
                                lastEncPtsUs = encInfo.presentationTimeUs
                                onProgress(
                                    (lastEncPtsUs.toFloat() / targetUs).coerceIn(0f, 1f)
                                )
                            }
                            if (encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                                encoderDone = true
                            }
                            activeEnc.releaseOutputBuffer(idx, false)
                        }
                    }
                }

                stall = if (progressed) 0 else stall + 1
                check(stall < 2_000) { "Audio processing stalled — the file may be corrupted" }
            }

            val aacFrameUs = 1_024L * 1_000_000L / sampleRate
            store.durationUs = lastEncPtsUs + aacFrameUs
        } finally {
            runCatching { decoder?.stop() }
            runCatching { decoder?.release() }
            runCatching { encoder?.stop() }
            runCatching { encoder?.release() }
            runCatching { extractor.release() }
        }
    }
}
