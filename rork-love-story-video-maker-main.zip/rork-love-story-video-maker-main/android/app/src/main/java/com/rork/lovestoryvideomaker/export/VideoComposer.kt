package com.rork.lovestoryvideomaker.export

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import com.rork.lovestoryvideomaker.model.ExportRequest
import com.rork.lovestoryvideomaker.model.HistoryItem
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

/**
 * Renders the final MP4: encodes one still-image GOP, transcodes the audio
 * to AAC, then loop-muxes both streams for the requested duration.
 * Memory stays flat because samples are streamed from disk.
 */
class VideoComposer(private val context: Context) {

    fun compose(
        request: ExportRequest,
        onProgress: (progress: Float, phase: String, etaMs: Long?) -> Unit,
        isCancelled: () -> Boolean
    ): HistoryItem {
        val startTime = SystemClock.elapsedRealtime()
        fun report(p: Float, phase: String) {
            val clamped = p.coerceIn(0f, 1f)
            val elapsed = SystemClock.elapsedRealtime() - startTime
            val eta = if (clamped > 0.06f) {
                (elapsed * (1f - clamped) / clamped).toLong()
            } else null
            onProgress(clamped, phase, eta)
        }

        val totalUs = request.durationMs * 1000L
        val fps = request.fps
        report(0.01f, "Preparing your photo")

        val source = loadBitmap(Uri.parse(request.imageUri))
        val portrait = source.height > source.width
        val outW = if (portrait) request.resolution.shortSide else request.resolution.longSide
        val outH = if (portrait) request.resolution.longSide else request.resolution.shortSide

        if (!StillImageEncoder.isResolutionSupported(outW, outH)) {
            source.recycle()
            throw IllegalStateException(
                "${request.resolution.label} (${outW}×${outH}) is not supported by this device. Please pick a lower resolution."
            )
        }

        val frame = composeFrame(source, outW, outH)
        val cacheDir = File(context.cacheDir, "export").apply { mkdirs() }
        val stamp = System.currentTimeMillis()
        val videoStore = SampleStore(File(cacheDir, "video_$stamp.bin"))
        val audioStore = SampleStore(File(cacheDir, "audio_$stamp.bin"))
        var output: OutputTarget? = null

        try {
            // Phase 1: encode one loopable video segment (5% -> 15%).
            val frameCount = fps * StillImageEncoder.LOOP_SECONDS
            val encoder = StillImageEncoder(outW, outH, fps, request.resolution.bitrate)
            encoder.encode(
                frame, frameCount, videoStore,
                onFrame = { n -> report(0.05f + 0.10f * n / frameCount, "Encoding video frames") },
                isCancelled = isCancelled
            )
            val videoFormat = encoder.outputFormat
                ?: throw IllegalStateException("The video encoder produced no output")

            // Phase 2: transcode audio to AAC (15% -> 40%).
            val transcoder = AudioTranscoder()
            transcoder.transcode(
                context, Uri.parse(request.audio.uri), totalUs, audioStore,
                onProgress = { p -> report(0.15f + 0.25f * p, "Processing audio") },
                isCancelled = isCancelled
            )
            val audioFormat = transcoder.outputFormat
                ?: throw IllegalStateException("The audio track could not be processed")
            if (audioStore.sampleCount == 0) {
                throw IllegalStateException("No audio data could be read from the selected file")
            }

            // Phase 3: loop-mux to the final MP4 (40% -> 98%).
            val fileName = "LoveStory_" +
                SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
            val target = OutputTarget.create(context, fileName)
            output = target
            mux(target.muxer, videoStore, videoFormat, audioStore, audioFormat, totalUs,
                onMuxProgress = { p, eta -> onProgress(0.40f + 0.58f * p, "Writing video file", eta) },
                isCancelled = isCancelled)

            report(0.99f, "Saving to gallery")
            target.finish(request.durationMs)
            val thumbPath = saveThumbnail(frame, stamp)
            report(1f, "Done")

            return HistoryItem(
                id = UUID.randomUUID().toString(),
                fileName = fileName,
                uri = target.contentUri.toString(),
                durationMs = request.durationMs,
                width = outW,
                height = outH,
                resolutionLabel = request.resolution.label,
                fps = fps,
                sizeBytes = target.resultSize(),
                dateMillis = System.currentTimeMillis(),
                thumbnailPath = thumbPath
            )
        } catch (t: Throwable) {
            output?.abort()
            throw t
        } finally {
            videoStore.close()
            audioStore.close()
            if (frame !== source) runCatching { frame.recycle() }
            runCatching { source.recycle() }
        }
    }

    private fun mux(
        muxer: MediaMuxer,
        videoStore: SampleStore,
        videoFormat: MediaFormat,
        audioStore: SampleStore,
        audioFormat: MediaFormat,
        totalUs: Long,
        onMuxProgress: (Float, Long?) -> Unit,
        isCancelled: () -> Boolean
    ) {
        val vTrack = muxer.addTrack(videoFormat)
        val aTrack = muxer.addTrack(audioFormat)
        muxer.start()
        videoStore.startReading()
        audioStore.startReading()

        val info = MediaCodec.BufferInfo()
        val vLoopDur = videoStore.durationUs
        val aLoopDur = audioStore.durationUs
        var vIdx = 0
        var vLoop = 0L
        var vDone = false
        var aIdx = 0
        var aLoop = 0L
        var aDone = false
        var vPts = videoStore.meta(0).ptsUs
        var aPts = audioStore.meta(0).ptsUs
        var written = 0L
        val muxStart = SystemClock.elapsedRealtime()

        while (!vDone || !aDone) {
            if (written and 511L == 0L && isCancelled()) throw ExportCancelledException()

            val useVideo = !vDone && (aDone || vPts <= aPts)
            if (useVideo) {
                if (vPts >= totalUs) {
                    vDone = true
                } else {
                    val m = videoStore.meta(vIdx)
                    info.set(0, m.size, vPts, m.flags)
                    muxer.writeSampleData(vTrack, videoStore.sampleBuffer(vIdx), info)
                    vIdx++
                    if (vIdx == videoStore.sampleCount) {
                        vIdx = 0
                        vLoop++
                    }
                    vPts = vLoop * vLoopDur + videoStore.meta(vIdx).ptsUs
                }
            } else {
                if (aPts >= totalUs) {
                    aDone = true
                } else {
                    val m = audioStore.meta(aIdx)
                    info.set(0, m.size, aPts, m.flags)
                    muxer.writeSampleData(aTrack, audioStore.sampleBuffer(aIdx), info)
                    aIdx++
                    if (aIdx == audioStore.sampleCount) {
                        aIdx = 0
                        aLoop++
                    }
                    aPts = aLoop * aLoopDur + audioStore.meta(aIdx).ptsUs
                }
            }

            written++
            if (written and 8191L == 0L) {
                val progressedUs = min(
                    if (vDone) totalUs else vPts,
                    if (aDone) totalUs else aPts
                )
                val p = progressedUs.toFloat() / totalUs
                val elapsed = SystemClock.elapsedRealtime() - muxStart
                val eta = if (p > 0.02f) (elapsed * (1f - p) / p).toLong() else null
                onMuxProgress(p, eta)
            }
        }
        muxer.stop()
    }

    private fun loadBitmap(uri: Uri): Bitmap {
        val resolver = context.contentResolver
        val bitmap = if (Build.VERSION.SDK_INT >= 28) {
            val src = ImageDecoder.createSource(resolver, uri)
            ImageDecoder.decodeBitmap(src) { decoder, decoderInfo, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = decoderInfo.size.width
                val h = decoderInfo.size.height
                val maxSide = 4096
                if (max(w, h) > maxSide) {
                    val scale = maxSide.toFloat() / max(w, h)
                    decoder.setTargetSize(
                        (w * scale).toInt().coerceAtLeast(1),
                        (h * scale).toInt().coerceAtLeast(1)
                    )
                }
            }
        } else {
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: throw IOException("Could not open the selected image")
        }
        return bitmap
    }

    /** Draws the photo fitted over a softly blurred, dimmed cover backdrop. */
    private fun composeFrame(src: Bitmap, outW: Int, outH: Int): Bitmap {
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

        val tinyW = (outW / 24).coerceAtLeast(1)
        val tinyH = (outH / 24).coerceAtLeast(1)
        val tiny = Bitmap.createScaledBitmap(src, tinyW, tinyH, true)
        val coverScale = max(outW.toFloat() / tiny.width, outH.toFloat() / tiny.height)
        val bw = tiny.width * coverScale
        val bh = tiny.height * coverScale
        val bl = (outW - bw) / 2f
        val bt = (outH - bh) / 2f
        canvas.drawBitmap(tiny, null, RectF(bl, bt, bl + bw, bt + bh), paint)
        canvas.drawColor(0x59000000)
        tiny.recycle()

        val fitScale = min(outW.toFloat() / src.width, outH.toFloat() / src.height)
        val fw = src.width * fitScale
        val fh = src.height * fitScale
        val fl = (outW - fw) / 2f
        val ft = (outH - fh) / 2f
        canvas.drawBitmap(src, null, RectF(fl, ft, fl + fw, ft + fh), paint)
        return out
    }

    private fun saveThumbnail(frame: Bitmap, stamp: Long): String? = try {
        val dir = File(context.filesDir, "thumbnails").apply { mkdirs() }
        val file = File(dir, "thumb_$stamp.jpg")
        val targetW = 480
        val targetH = (frame.height * (targetW.toFloat() / frame.width)).toInt().coerceAtLeast(1)
        val thumb = Bitmap.createScaledBitmap(frame, targetW, targetH, true)
        FileOutputStream(file).use { thumb.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        thumb.recycle()
        file.absolutePath
    } catch (_: Exception) {
        null
    }
}
