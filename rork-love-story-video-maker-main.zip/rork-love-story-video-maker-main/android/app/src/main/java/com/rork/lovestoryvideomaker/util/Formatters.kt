package com.rork.lovestoryvideomaker.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Formatters {

    /** "1h 30m", "45 min", "0:42" style human duration. */
    fun duration(ms: Long): String {
        val totalSeconds = ms / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return when {
            hours > 0 && minutes > 0 -> "${hours}h ${minutes}m"
            hours > 0 -> "${hours}h"
            minutes > 0 && seconds > 0 -> "${minutes}m ${seconds}s"
            minutes > 0 -> "$minutes min"
            else -> "${seconds}s"
        }
    }

    /** "03:45" or "1:02:30" playback style timestamp. */
    fun timestamp(ms: Long): String {
        val totalSeconds = ms / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun fileSize(bytes: Long): String {
        if (bytes <= 0) return "—"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1 -> String.format(Locale.US, "%.2f GB", gb)
            mb >= 1 -> String.format(Locale.US, "%.1f MB", mb)
            else -> String.format(Locale.US, "%.0f KB", kb)
        }
    }

    fun date(millis: Long): String =
        SimpleDateFormat("MMM d, yyyy · h:mm a", Locale.US).format(Date(millis))

    /** Rough ETA text like "about 2 min left". */
    fun eta(ms: Long): String {
        val minutes = ms / 60_000
        val seconds = (ms % 60_000) / 1000
        return when {
            minutes >= 60 -> "about ${minutes / 60}h ${minutes % 60}m left"
            minutes > 0 -> "about ${minutes + 1} min left"
            else -> "${seconds}s left"
        }
    }
}
