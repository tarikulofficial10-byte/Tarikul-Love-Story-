package com.rork.lovestoryvideomaker.export

import android.media.MediaCodec
import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * Disk-backed store for encoded media samples. Samples are appended once,
 * then memory-mapped for zero-copy repeated reads while loop-muxing.
 * Keeps memory usage flat regardless of export length.
 */
class SampleStore(private val file: File) : Closeable {

    data class Meta(val offset: Long, val size: Int, val ptsUs: Long, val flags: Int)

    private val metas = ArrayList<Meta>()
    private var output: BufferedOutputStream? =
        BufferedOutputStream(FileOutputStream(file), 1 shl 16)
    private var writeOffset = 0L
    private var mapped: MappedByteBuffer? = null
    private var readChannel: FileChannel? = null

    /** Exact duration of one loop of this sample segment, set by the producer. */
    var durationUs: Long = 0

    val sampleCount: Int get() = metas.size

    fun meta(index: Int): Meta = metas[index]

    fun append(buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        val sink = output ?: error("SampleStore is sealed for reading")
        val bytes = ByteArray(info.size)
        buffer.position(info.offset)
        buffer.limit(info.offset + info.size)
        buffer.get(bytes)
        sink.write(bytes)
        // Only the keyframe flag is meaningful when re-writing samples.
        val flags = info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME
        metas.add(Meta(writeOffset, info.size, info.presentationTimeUs, flags))
        writeOffset += info.size
    }

    /** Seals the store and memory-maps the sample data for reading. */
    fun startReading() {
        output?.flush()
        output?.close()
        output = null
        check(writeOffset > 0 && metas.isNotEmpty()) { "SampleStore is empty" }
        val channel = FileInputStream(file).channel
        readChannel = channel
        mapped = channel.map(FileChannel.MapMode.READ_ONLY, 0, writeOffset)
    }

    /** Returns a zero-copy view of one sample's bytes. */
    fun sampleBuffer(index: Int): ByteBuffer {
        val m = metas[index]
        val buf = mapped?.duplicate() ?: error("startReading() was not called")
        buf.position(m.offset.toInt())
        buf.limit((m.offset + m.size).toInt())
        return buf.slice()
    }

    override fun close() {
        runCatching { output?.close() }
        runCatching { readChannel?.close() }
        output = null
        mapped = null
        runCatching { file.delete() }
    }
}
