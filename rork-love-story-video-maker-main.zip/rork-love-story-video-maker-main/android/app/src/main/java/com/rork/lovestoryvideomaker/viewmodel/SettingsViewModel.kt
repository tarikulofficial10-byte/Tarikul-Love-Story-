package com.rork.lovestoryvideomaker.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.rork.lovestoryvideomaker.data.SettingsRepository
import com.rork.lovestoryvideomaker.model.AppSettings
import com.rork.lovestoryvideomaker.model.Resolution
import com.rork.lovestoryvideomaker.model.ThemeMode
import kotlinx.coroutines.flow.StateFlow

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SettingsRepository.getInstance(application)

    val settings: StateFlow<AppSettings> = repository.settings

    fun setDefaultResolution(resolution: Resolution) = repository.setDefaultResolution(resolution)

    fun setFrameRate(fps: Int) = repository.setFrameRate(fps)

    fun setThemeMode(mode: ThemeMode) = repository.setThemeMode(mode)
}
