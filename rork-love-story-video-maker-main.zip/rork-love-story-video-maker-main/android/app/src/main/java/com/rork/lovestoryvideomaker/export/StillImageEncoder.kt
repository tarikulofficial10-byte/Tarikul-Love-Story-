package com.rork.lovestoryvideomaker.export

import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat

/**
 * Encodes a short H.264 loop segment (one GOP) of a still image.
 * The segment is later re-written with shifted timestamps for the full
 * video duration, so even multi-hour exports encode in seconds.
 */
class StillImageEncoder(
    private val width: Int,
    private val height: Int,
    private val fps: Int,
    private val bitrate: Int
) {
    var outputFormat: MediaFormat? = null
        private set

    fun encode(
        bitmap: Bitmap,
        frameCount: Int,
        store: SampleStore,
        onFrame: (Int) -> Unit,
        isCancelled: () -> Boolean
    ) {
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
            )
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, LOOP_SECONDS)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            val i420 = YuvConverter.fromBitmap(bitmap)
            val frameBytes = width * height * 3 / 2
            val info = MediaCodec.BufferInfo()
            var framesFed = 0
            var eosSent = false
            var done = false
            var stall = 0

            while (!done) {
                if (isCancelled()) throw ExportCancelledException()
                var progressed = false

                if (!eosSent) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        progressed = true
                        if (framesFed == frameCount) {
                            codec.queueInputBuffer(
                                inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            eosSent = true
                        } else {
                            val image = codec.getInputImage(inIdx)
                                ?: throw IllegalStateException("Encoder rejected image input")
                            YuvConverter.fill(image, i420)
                            val ptsUs = framesFed * 1_000_000L / fps
                            codec.queueInputBuffer(inIdx, 0, frameBytes, ptsUs, 0)
                            framesFed++
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        outputFormat = codec.outputFormat
                        progressed = true
                    }
                    outIdx >= 0 -> {
                        progressed = true
                        val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                        if (!isConfig && info.size > 0) {
                            store.append(codec.getOutputBuffer(outIdx)!!, info)
                            onFrame(store.sampleCount)
                        }
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) done = true
                        codec.releaseOutputBuffer(outIdx, false)
                    }
                }

                stall = if (progressed) 0 else stall + 1
                check(stall < 1_000) { "Video encoder stalled" }
            }
            store.durationUs = frameCount * 1_000_000L / fps
        } finally {
            runCatching { codec.stop() }
            runCatching { codec.release() }
        }
    }

    companion object {
        /** Seconds per encoded loop segment; also the keyframe interval. */
        const val LOOP_SECONDS = 2

        fun isResolutionSupported(width: Int, height: Int): Boolean {
            return try {
                val probe = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height)
                MediaCodecList(MediaCodecList.REGULAR_CODECS).findEncoderForFormat(probe) != null
            } catch (_: Exception) {
                false
            }
        }
    }
}
