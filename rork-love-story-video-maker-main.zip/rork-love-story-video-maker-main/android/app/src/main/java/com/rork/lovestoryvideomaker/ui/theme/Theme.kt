package com.rork.lovestoryvideomaker.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.rork.lovestoryvideomaker.R

val PlayfairDisplay = FontFamily(Font(R.font.playfair_display))

private val LightColors = lightColorScheme(
    primary = Color(0xFF9C2B54),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFD9E3),
    onPrimaryContainer = Color(0xFF3F0022),
    secondary = Color(0xFF95682B),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF9E1BC),
    onSecondaryContainer = Color(0xFF2F2000),
    tertiary = Color(0xFF7B4E63),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFFFD8E7),
    onTertiaryContainer = Color(0xFF31101F),
    background = Color(0xFFFFF7F6),
    onBackground = Color(0xFF23181C),
    surface = Color(0xFFFFFBFB),
    onSurface = Color(0xFF23181C),
    surfaceVariant = Color(0xFFF4DEE4),
    onSurfaceVariant = Color(0xFF534349),
    outline = Color(0xFF857379),
    outlineVariant = Color(0xFFD7C2C8),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFFFF0F2),
    surfaceContainer = Color(0xFFFBEAEE),
    surfaceContainerHigh = Color(0xFFF5E4E8),
    surfaceContainerHighest = Color(0xFFEFDEE2)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFFB0C9),
    onPrimary = Color(0xFF601237),
    primaryContainer = Color(0xFF7D2A4E),
    onPrimaryContainer = Color(0xFFFFD9E3),
    secondary = Color(0xFFE9C287),
    onSecondary = Color(0xFF432C00),
    secondaryContainer = Color(0xFF745A17),
    onSecondaryContainer = Color(0xFFF9E1BC),
    tertiary = Color(0xFFECB4CC),
    onTertiary = Color(0xFF482534),
    tertiaryContainer = Color(0xFF613B4B),
    onTertiaryContainer = Color(0xFFFFD8E7),
    background = Color(0xFF190F14),
    onBackground = Color(0xFFF0DDE2),
    surface = Color(0xFF1E1218),
    onSurface = Color(0xFFF0DDE2),
    surfaceVariant = Color(0xFF3E2A32),
    onSurfaceVariant = Color(0xFFD7C2C8),
    outline = Color(0xFF9F8C93),
    outlineVariant = Color(0xFF534349),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    surfaceContainerLowest = Color(0xFF120A0E),
    surfaceContainerLow = Color(0xFF221419),
    surfaceContainer = Color(0xFF27171E),
    surfaceContainerHigh = Color(0xFF322028),
    surfaceContainerHighest = Color(0xFF3D2A33)
)

private val AppTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = PlayfairDisplay,
        fontWeight = FontWeight.Bold,
        fontSize = 52.sp,
        lineHeight = 58.sp
    ),
    displayMedium = TextStyle(
        fontFamily = PlayfairDisplay,
        fontWeight = FontWeight.Bold,
        fontSize = 42.sp,
        lineHeight = 48.sp
    ),
    displaySmall = TextStyle(
        fontFamily = PlayfairDisplay,
        fontWeight = FontWeight.Bold,
        fontSize = 34.sp,
        lineHeight = 40.sp
    ),
    headlineLarge = TextStyle(
        fontFamily = PlayfairDisplay,
        fontWeight = FontWeight.Bold,
        fontSize = 30.sp,
        lineHeight = 36.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = PlayfairDisplay,
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        lineHeight = 32.sp
    ),
    headlineSmall = TextStyle(
        fontFamily = PlayfairDisplay,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    titleLarge = TextStyle(
        fontFamily = PlayfairDisplay,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 26.sp
    )
)

@Composable
fun AppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content
    )
}
