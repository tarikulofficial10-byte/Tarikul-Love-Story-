package com.rork.lovestoryvideomaker.model

/** Everything the export engine needs to render one video. */
data class ExportRequest(
    val imageUri: String,
    val audio: AudioInfo,
    val durationMs: Long,
    val resolution: Resolution,
    val fps: Int
)
