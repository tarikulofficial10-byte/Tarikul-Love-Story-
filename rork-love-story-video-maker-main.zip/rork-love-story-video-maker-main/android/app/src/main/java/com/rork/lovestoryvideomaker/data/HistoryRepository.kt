package com.rork.lovestoryvideomaker.data

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.util.Log
import com.rork.lovestoryvideomaker.model.HistoryItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.Json
import java.io.File

/** Stores the export history as JSON and mirrors it into a StateFlow. */
class HistoryRepository private constructor(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("history", Context.MODE_PRIVATE)

    private val json = Json { ignoreUnknownKeys = true }

    private val _items = MutableStateFlow<List<HistoryItem>>(load())
    val items: StateFlow<List<HistoryItem>> = _items.asStateFlow()

    private fun load(): List<HistoryItem> {
        val raw = prefs.getString(KEY_ITEMS, null) ?: return emptyList()
        return try {
            json.decodeFromString<List<HistoryItem>>(raw)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse history", e)
            emptyList()
        }
    }

    private fun persist(items: List<HistoryItem>) {
        _items.value = items
        prefs.edit().putString(KEY_ITEMS, json.encodeToString(items)).apply()
    }

    @Synchronized
    fun add(item: HistoryItem) {
        persist(listOf(item) + _items.value)
    }

    /** Removes the entry, its gallery file, and its cached thumbnail. */
    @Synchronized
    fun delete(item: HistoryItem) {
        try {
            context.contentResolver.delete(Uri.parse(item.uri), null, null)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete media file", e)
        }
        item.thumbnailPath?.let { path ->
            runCatching { File(path).delete() }
        }
        persist(_items.value.filterNot { it.id == item.id })
    }

    companion object {
        private const val TAG = "HistoryRepository"
        private const val KEY_ITEMS = "items"

        @Volatile
        private var instance: HistoryRepository? = null

        fun getInstance(context: Context): HistoryRepository =
            instance ?: synchronized(this) {
                instance ?: HistoryRepository(context.applicationContext).also { instance = it }
            }
    }
}
