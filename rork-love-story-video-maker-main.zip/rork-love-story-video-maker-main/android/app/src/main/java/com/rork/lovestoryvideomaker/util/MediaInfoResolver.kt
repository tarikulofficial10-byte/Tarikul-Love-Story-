package com.rork.lovestoryvideomaker.util

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.rork.lovestoryvideomaker.model.AudioInfo

/** Reads display name, size, and duration for a picked audio Uri. */
object MediaInfoResolver {

    fun resolveAudio(context: Context, uri: Uri): AudioInfo {
        var name = "Audio track"
        var size = 0L
        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null, null, null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIdx >= 0 && !cursor.isNull(nameIdx)) name = cursor.getString(nameIdx)
                if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) size = cursor.getLong(sizeIdx)
            }
        }

        var durationMs = 0L
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            durationMs = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            // Leave duration unknown; the transcoder will still handle it.
        } finally {
            runCatching { retriever.release() }
        }

        val mime = context.contentResolver.getType(uri)
        return AudioInfo(
            uri = uri.toString(),
            name = name,
            durationMs = durationMs,
            sizeBytes = size,
            mimeType = mime
        )
    }
}
